drop table FactSalesTransaction;
drop table DimStore;
drop table DimProduct;
drop table DimPromotion;
drop table DimDate;

